# Temujin & Kabli Stucco Site

This is the starter template for your stucco repair website.

## 🚀 How to Deploy

### Option 1: GitHub Pages
1. Push this folder to a GitHub repository
2. Go to Repository Settings → Pages
3. Set source to `main` branch and root
4. Access your site at: https://your-username.github.io/repo-name/

### Option 2: Google Cloud Storage
1. Create a GCS bucket with public read access
2. Upload `index.html` and `style.css`
3. Enable static website hosting
4. Point your domain through Cloudflare DNS

---

📞 801-484-7409  
📧 Stanthestuccomanut@gmail.com
